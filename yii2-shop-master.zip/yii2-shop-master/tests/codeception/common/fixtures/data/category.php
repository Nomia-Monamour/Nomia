<?php
return [
    [
        'id' => 1,
        'parent_id' => null,
        'title' => 'Cars',
        'slug' => 'cars',
    ],
    [
        'id' => 2,
        'parent_id' => null,
        'title' => 'Carpets',
        'slug' => 'carpets',
    ],
    [
        'id' => 3,
        'parent_id' => 2,
        'title' => 'Persian',
        'slug' => 'persian',
    ],
    [
        'id' => 4,
        'parent_id' => 2,
        'title' => 'Russian',
        'slug' => 'russian',
    ],
    [
        'id' => 5,
        'parent_id' => 1,
        'title' => 'Sport',
        'slug' => 'sport',
    ],
    [
        'id' => 6,
        'parent_id' => 1,
        'title' => 'City',
        'slug' => 'city',
    ],
    [
        'id' => 7,
        'parent_id' => 1,
        'title' => 'Countryside',
        'slug' => 'countryside',
    ],
];